﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(JNSolution.Startup))]
namespace JNSolution
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
