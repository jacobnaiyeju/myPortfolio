﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using JNSolution.Models;

namespace JNSolution.Controllers
{
    public class TemplateController : Controller
    {
        private JacobNaiyejuSolutionContext db = new JacobNaiyejuSolutionContext();

        // GET: Template
        public ActionResult Index()
        {
            return View(db.personaldatas.ToList());
        }

        // GET: Template/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            personaldata personaldata = db.personaldatas.Find(id);
            if (personaldata == null)
            {
                return HttpNotFound();
            }
            return View(personaldata);
        }

        // GET: Template/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Template/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,firstname,lastname,hometown,spousename,firstkidname,secondkidname,yourName,address")] personaldata personaldata)
        {
            if (ModelState.IsValid)
            {
                db.personaldatas.Add(personaldata);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(personaldata);
        }

        // GET: Template/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            personaldata personaldata = db.personaldatas.Find(id);
            if (personaldata == null)
            {
                return HttpNotFound();
            }
            return View(personaldata);
        }

        // POST: Template/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,firstname,lastname,hometown,spousename,firstkidname,secondkidname,yourName,address")] personaldata personaldata)
        {
            if (ModelState.IsValid)
            {
                db.Entry(personaldata).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(personaldata);
        }

        // GET: Template/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            personaldata personaldata = db.personaldatas.Find(id);
            if (personaldata == null)
            {
                return HttpNotFound();
            }
            return View(personaldata);
        }

        // POST: Template/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            personaldata personaldata = db.personaldatas.Find(id);
            db.personaldatas.Remove(personaldata);
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult MyAction(int id)
        {

            if (id == 1)
            {
                return PartialView("_MyPartial");
            }
            else if (id == 2)
            {
                return PartialView("_MyPartial2");
            }
            else
            {
                return PartialView("_MyPartial3");
            }
            
        }
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
