-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2014 at 11:09 PM
-- Server version: 5.6.11
-- PHP Version: 5.5.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bootprofile`
--
CREATE DATABASE IF NOT EXISTS `bootprofile` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `bootprofile`;

-- --------------------------------------------------------

--
-- Table structure for table `achievement`
--

CREATE TABLE IF NOT EXISTS `achievement` (
  `achievementId` int(10) NOT NULL AUTO_INCREMENT,
  `achievementCode` varchar(50) NOT NULL,
  `englishLeague` int(10) DEFAULT NULL,
  `FACup` int(11) DEFAULT NULL,
  `leagueCup` int(11) DEFAULT NULL,
  `communityShield` int(11) DEFAULT NULL,
  `laLiga` int(11) DEFAULT NULL,
  `copadelRey` int(11) DEFAULT NULL,
  `supercopadeEspana` int(11) DEFAULT NULL,
  `serieA` int(11) DEFAULT NULL,
  `coppaItalia` int(11) DEFAULT NULL,
  `supercoppaItaliana` int(11) DEFAULT NULL,
  `bundesLiga` int(11) DEFAULT NULL,
  `DFBPokal` int(11) DEFAULT NULL,
  `championsLeague` int(11) DEFAULT NULL,
  `europaLeague` int(11) DEFAULT NULL,
  `FIFAClubWorldCup` int(11) DEFAULT NULL,
  `worldCup` int(11) DEFAULT NULL,
  `ballondOr` int(11) DEFAULT NULL,
  `europeanGoldenShoe` int(11) DEFAULT NULL,
  `FIFAWorldPlayeroftheYear` int(11) DEFAULT NULL,
  `PichichiTrophy` int(11) DEFAULT NULL,
  `UEFABestPlayerinEuropeAward` int(11) DEFAULT NULL,
  `PFAPlayersPlayeroftheYear` int(11) DEFAULT NULL,
  `PremierLeagueGoldenBoot` int(11) DEFAULT NULL,
  `BundesligatopSoccer` int(11) DEFAULT NULL,
  `serieATopLeagueGoalSoccer` int(11) DEFAULT NULL,
  `laLigaTopGoalSoccer` int(11) DEFAULT NULL,
  PRIMARY KEY (`achievementId`),
  UNIQUE KEY `achievementCode` (`achievementCode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `achievement`
--

INSERT INTO `achievement` (`achievementId`, `achievementCode`, `englishLeague`, `FACup`, `leagueCup`, `communityShield`, `laLiga`, `copadelRey`, `supercopadeEspana`, `serieA`, `coppaItalia`, `supercoppaItaliana`, `bundesLiga`, `DFBPokal`, `championsLeague`, `europaLeague`, `FIFAClubWorldCup`, `worldCup`, `ballondOr`, `europeanGoldenShoe`, `FIFAWorldPlayeroftheYear`, `PichichiTrophy`, `UEFABestPlayerinEuropeAward`, `PFAPlayersPlayeroftheYear`, `PremierLeagueGoldenBoot`, `BundesligatopSoccer`, `serieATopLeagueGoalSoccer`, `laLigaTopGoalSoccer`) VALUES
(1, '99f0595502ba4ae78f3290d97b589254', 2, NULL, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'EL001001', 13, 11, 2, 13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'd16544252e0841f88750c3934aa864a4', NULL, NULL, 1, 1, 1, 1, 1, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'EL001002', 7, 7, 5, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'b67d058eab3340a4b1f2b9a78edc3495', 1, NULL, NULL, NULL, NULL, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, '3ae3bb43bafc4ef3bffac32c741eb5bb', 3, 3, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(7, 'EL001003', 2, 1, NULL, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'EL001004', 4, 7, 4, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'cc6d0c2a88ca49e1a02eca90068824f4', 3, 5, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL),
(10, 'cc41c78841a24c2bab27cb06428a5eb8', 3, 4, 2, 2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'EL001005', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(12, '742b57d87f6f402ca29984079d2f40dc', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(14, 'c166572a1bec4dbeab66774830b8df0e', NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(16, '6cb88531991c4536b3acd5e3b1c9b367', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(17, '35781f6160af4aaabd3031cdbb096bc5', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(18, 'EL001006', 9, 5, NULL, 9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(19, '612cbf16b88a4c1180de633ea01d785a', NULL, NULL, NULL, NULL, 3, 2, NULL, NULL, 2, 1, NULL, NULL, 1, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(20, '8af5792922324866a0d020fc1555d07c', 1, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(21, 'EL001007', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(22, '16b3b6b17b24474d8fe9404ee4175b76', NULL, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(23, 'b9bfed3a036d4f4096b7e6861f3cbe6b', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(24, 'EL001008', NULL, NULL, 3, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(25, '3fd77c1efef14366b780c1004b5ed300', NULL, NULL, NULL, NULL, 1, NULL, NULL, 5, 4, 4, NULL, NULL, 1, NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(26, '1d3d7a09286a4f37ad6c675ebabb9903', NULL, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(27, 'EL001009', 18, 7, 8, 15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, 3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE IF NOT EXISTS `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `foreName` varchar(11) NOT NULL,
  `surName` varchar(11) NOT NULL,
  `messageType` varchar(11) NOT NULL,
  `comment` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

CREATE TABLE IF NOT EXISTS `division` (
  `divisionId` int(11) NOT NULL AUTO_INCREMENT,
  `leagueCode` varchar(20) NOT NULL,
  `divisionCode` varchar(10) NOT NULL,
  `divisionAlias` varchar(30) DEFAULT NULL,
  `divisionName` varchar(50) NOT NULL,
  `divisionLogo` varchar(50) NOT NULL,
  PRIMARY KEY (`divisionCode`),
  UNIQUE KEY `divisionId` (`divisionId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`divisionId`, `leagueCode`, `divisionCode`, `divisionAlias`, `divisionName`, `divisionLogo`) VALUES
(1, 'EnglishLeague', 'EL001', 'EPL', 'Barclays Premier League', '/images/divisions/PremierLeagueLogo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `league`
--

CREATE TABLE IF NOT EXISTS `league` (
  `leagueId` int(11) NOT NULL AUTO_INCREMENT,
  `leagueCode` varchar(20) NOT NULL,
  `leagueName` varchar(50) NOT NULL,
  `leagueLogo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`leagueCode`),
  UNIQUE KEY `leagueId` (`leagueId`,`leagueName`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `league`
--

INSERT INTO `league` (`leagueId`, `leagueCode`, `leagueName`, `leagueLogo`) VALUES
(1, 'EnglishLeague', 'English Premier League', './images/leagues/englishLeague.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `loginId` int(11) NOT NULL AUTO_INCREMENT,
  `userId` varchar(40) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `roleCode` char(2) NOT NULL,
  PRIMARY KEY (`loginId`),
  UNIQUE KEY `userId` (`userId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`loginId`, `userId`, `username`, `password`, `roleCode`) VALUES
(1, '85c96b0b26074eeaa298a45c94365443', 'Admin', 'Admin', 'AD');

-- --------------------------------------------------------

--
-- Table structure for table `manager`
--

CREATE TABLE IF NOT EXISTS `manager` (
  `managerId` int(11) NOT NULL AUTO_INCREMENT,
  `managerCode` varchar(10) NOT NULL,
  `managerName` varchar(40) NOT NULL,
  `managerAge` int(11) DEFAULT NULL,
  `managerNationality` varchar(40) NOT NULL,
  `managerImage` varchar(50) NOT NULL,
  PRIMARY KEY (`managerCode`),
  UNIQUE KEY `managerId` (`managerId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `manager`
--

INSERT INTO `manager` (`managerId`, `managerCode`, `managerName`, `managerAge`, `managerNationality`, `managerImage`) VALUES
(1, 'MG001', 'Arsène Wenger', 65, 'France', 'images/managers/ArseneWenger.jpg'),
(2, 'MG002', 'Paul Lambert', 45, 'Scotland', 'images/managers/AstonVillaLambert.jpg'),
(3, 'MG003', 'Sean Dyche', 43, 'England', 'images/managers/BurnleySeanDyche.jpg'),
(8, 'MG004', 'José Mourinho', 51, 'Portugal', 'images/managers/ChelseaJoseMourinho.jpg'),
(9, 'MG005', 'Neil Warnock', 65, 'England', 'images/managers/CrystalPalaceWarnock.jpg'),
(10, 'MG006', 'Roberto Martínez', 41, 'spain', 'images/managers/EvertonRobertoMartínez.jpg'),
(11, 'MG007', 'Steve Bruce', 53, 'England', 'images/managers/HullCitySteveBruce.jpg'),
(12, 'MG008', 'Nigel Pearson', 51, 'England', 'images/managers/LeicesterCityNigelPearson.jpg'),
(13, 'MG009', 'Brendan Rodgers', 41, 'Northern Ireland', 'images/managers/LiverpoolBrendanRodgers.jpg'),
(14, 'MG010', 'Manuel Pellegrini', 61, 'Chile', 'images/managers/ManCityManuelPellegrini.jpg'),
(15, 'MG011', 'Louis van Gaal', 63, 'Netherlands', 'images/managers/ManUtdLouisvangaal.jpg'),
(16, 'MG012', 'Alan Pardew', 53, 'England', 'images/managers/NewcastleAlanpardew.jpg'),
(17, 'MG013', 'Harry Redknapp', 67, 'England', 'images/managers/QPRHarryRedknapp.jpg'),
(18, 'MG014', 'Ronald Koeman', 51, 'Netherlands', 'images/managers/SouthamtonKoeman.jpg'),
(19, 'MG015', ' Mark Hughes', 51, 'Wales', 'images/managers/StokeCityMarkHughes.jpg'),
(20, 'MG016', 'Gus Poyet', 47, 'Uruguay', 'images/managers/SunderlandBrighton.jpg'),
(21, 'MG017', 'Garry Monk', 35, 'England', 'images/managers/SwanseaGarryAlanMonk.jpg'),
(22, 'MG018', ' Mauricio Pochettino', 42, 'Argentina', 'images/managers/TottenhamPochettino.jpg'),
(23, 'MG019', 'Alan Irvine', 56, 'Scotland', 'images/managers/Westbromalanitrvine.jpg'),
(24, 'MG020', 'Sam Allardyce', 60, 'England', 'images/managers/WestHamSamallardyce.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `player`
--

CREATE TABLE IF NOT EXISTS `player` (
  `playerId` int(10) NOT NULL AUTO_INCREMENT,
  `playerCode` varchar(40) NOT NULL,
  `teamCode` varchar(10) NOT NULL,
  `playerImage` varchar(50) NOT NULL,
  `playerName` varchar(30) NOT NULL,
  `playerPossition` varchar(20) NOT NULL,
  PRIMARY KEY (`playerCode`),
  UNIQUE KEY `playerId` (`playerId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=301 ;

--
-- Dumping data for table `player`
--

INSERT INTO `player` (`playerId`, `playerCode`, `teamCode`, `playerImage`, `playerName`, `playerPossition`) VALUES
(274, '03835bc58d7547f990c3295ff8438191', 'EL001015', 'images/players/Stoke/Odemwingie.jpg', 'Peter Odemwingie', 'CF'),
(280, '07296822bd674c40b2a773c4acffa3ed', 'EL001016', 'images/players/Sunderland/Fletcher.jpg', 'Steven Fletcher', 'CF'),
(41, '075c57b8f8c94b2a8d44b5b881fdddaf', 'EL001001', 'images/players/Arsenal/campbell.jpg', 'Joel Campbell', 'FW'),
(15, '086f7117229c4ba7aa67bf79d38e401e', 'EL001001', 'images/players/Arsenal/rosicky.jpg', 'Tomas Rosicky', 'MID'),
(278, '0941d3f4f8f045e99e561100cccc5b1b', 'EL001016', 'images/players/Sunderland/Johnson.jpg', 'Adam Johnson', 'MID'),
(263, '095d1df787de4d1caa1ef2a6d0efaa9f', 'EL001013', 'images/players/QPR/Taarabt.jpg', 'Adel Taarabt', 'MID'),
(266, '09fb6d4853054466a11dfdd6885ebc23', 'EL001014', 'images/players/Southampton/Davis.jpg', 'Kelvin Davis', 'GK'),
(75, '0cf37e2914af4dcd8546c3a9906cbebe', 'EL001004', 'images/players/Chelsea/Cahill.jpg', 'Gary Cahill', 'DF'),
(245, '0d082ab622064b579c7804eaca757f0f', 'EL001009', 'images/players/Liverpool/Sturridge.jpg', 'Daniel Sturridge', 'CF'),
(199, '0d6593b503884b5fac98e42f5fab5c25', 'EL001005', 'images/players/crystal palace/speroni.jpg', 'Julian Speroni', 'GK'),
(17, '114ffd62668a4ad0bd273532c916bc89', 'EL001001', 'images/players/Arsenal/wilshere.jpg', 'Jack Wilshere', 'MID'),
(198, '130a1b787fb74b7c89d26bf909601f46', 'EL001005', 'images/players/crystal palace/price.jpg', 'Lewis Price', 'GK'),
(16, '135e4e3e0e884c5f94aad2f1ec78f1a0', 'EL001001', 'images/players/Arsenal/arteta.jpg', 'Mikel Arteta', 'MID'),
(91, '14fbad6d595c4ca1b2c77e80088b9784', 'EL001004', 'images/players/Chelsea/Remy.jpg', 'Loic Remy', 'MID'),
(281, '161ddf3575fb4142a2ab16944f609928', 'EL001017', 'images/players/Swansea/Fabianski.jpg', 'Lukasz Fabianski', 'GK'),
(233, '16b3b6b17b24474d8fe9404ee4175b76', 'EL001007', 'images/players/HullCity/Huddlestone.jpg', 'Tom Huddlestone', 'MID'),
(48, '190f8de4eda54c09b4567437786f5461', 'EL001002', 'images/players/Astonvilla/senderos.jpg', 'Phillipe Senderos', 'DF'),
(207, '1a19e8697db849e5aaed14c8b298de99', 'EL001005', 'images/players/crystal palace/Bannan.jpg', 'Barry Bannan', 'MID'),
(238, '1d3d7a09286a4f37ad6c675ebabb9903', 'EL001008', 'images/players/Leicester/David.jpg', 'David Nugent', 'CF'),
(271, '1ec5eb6ec7614afe993399056ae61a89', 'EL001015', 'images/players/Stoke/Begovic.jpg', 'Asmir Begovic', 'GK'),
(297, '20d60febd6844f56957bb82a044cf729', 'EL001020', 'images/players/WestHam/Jenkinson.jpg', 'Carl Jenkinson', 'DF'),
(78, '2728d7c1a7134e619e5ea635cf45f9c1', 'EL001004', 'images/players/Chelsea/Chriesstensen.jpg', 'Andreas Christensen', 'DF'),
(57, '28a669fbb2f34d95b6f5d7fd475db072', 'EL001002', 'images/players/Astonvilla/herd.jpg', 'Chris Herd', 'MID'),
(261, '2adbd37341d64e18bbadd56784a54938', 'EL001013', 'images/players/QPR/Green.jpg', 'Robert Green', 'GK'),
(14, '2ddd225668234ffb992b9325f1ed254b', 'EL001001', 'images/players/Arsenal/chambers.jpg', 'Calum Chambers', 'DF'),
(33, '2e9806d907354063ad8a3ceb21fa044e', 'EL001001', 'images/players/Arsenal/lukas.jpg', 'Lukas Podolski', 'FW'),
(3, '30f08c7d60d84de89c31741c7a7db6d0', 'EL001001', 'images/players/Arsenal/martinez.jpg', 'Emiliano Martinez', 'GK'),
(221, '311ab9faf8124fa8848a09d4df733abc', 'EL001003', 'images/players/Burnley/Ings.jpg', 'Danny Ings', 'CF'),
(272, '31b3375256fa475cae81adb4cabfd7c6', 'EL001015', 'images/players/Stoke/Shawcross.jpg', 'Ryan Shawcross', 'DF'),
(248, '329a30d07e4142bb9345a130221dc4f8', 'EL001010', 'images/players/ManCity/Silva.jpg', 'David Silva', 'MID'),
(269, '35226d1844fd4b128a8f266d0909d987', 'EL001014', 'images/players/Southampton/Long.jpg', 'Shane Long', 'CF'),
(218, '35781f6160af4aaabd3031cdbb096bc5', 'EL001005', 'images/players/crystal palace/Gayle.jpg', 'Dwight Gayle', 'ST'),
(286, '3617e2a2aee84d7cbca40205edb20054', 'EL001018', 'images/players/Tottenham/Lloris.jpg', 'Hugo Lloris', 'GK'),
(219, '36f2d53fbc894a2b93a70d7efa53add5', 'EL001005', 'images/players/crystal palace/Jerome.jpg', 'Cameron Jerome', 'ST'),
(70, '398023205360472b93da9ae488edc0b3', 'EL001004', 'images/players/Chelsea/Mark.jpg', 'Mark Schwarzer', 'GK'),
(63, '3a4444d34bbc4f32b6f13bef16e95566', 'EL001002', 'images/players/Astonvilla/gabriel.jpg', 'Gabriel Agbonlahor', 'ST'),
(54, '3ae3bb43bafc4ef3bffac32c741eb5bb', 'EL001002', 'images/players/Astonvilla/cole.jpg', 'Joe Cole', 'MID'),
(67, '3b49043c0d91499e8bbcdfec5f53ff9f', 'EL001002', 'images/players/Astonvilla/burke.jpg', 'Graham Burke', 'ST'),
(279, '3c18bf650ac2472395f3a984426fcb9c', 'EL001016', 'images/players/Sunderland/Altidore.jpg', 'Jozy Altidore', 'CF'),
(276, '3ca5babe3e524cf3a71cd48b462b2e43', 'EL001016', 'images/players/Sunderland/Vito.jpg', 'Vito Mannone', 'GK'),
(215, '3e3992d2a4b34c759d31b29996050bb9', 'EL001005', 'images/players/crystal palace/Thomas.jpg', 'Jerome Thomas', 'MID'),
(236, '3f9514e25261495caaf4a56f9511ad79', 'EL001008', 'images/players/Leicester/Kasper.jpg', 'Kasper Schmeichel', 'GK'),
(240, '3fd77c1efef14366b780c1004b5ed300', 'EL001008', 'images/players/Leicester/Cambiasso.jpg', 'Esteban Cambiasso', 'MID'),
(251, '40dcb4af61584d089be69bbd0934d483', 'EL001011', 'images/players/Manutd/Degea.jpg', 'De Gea', 'GK'),
(250, '40f37dc86a80486d93194257f7cad6f2', 'EL001010', 'images/players/ManCity/Aguero.jpg', 'Kun Agüero', 'CF'),
(208, '4241f7a10aca4287988fff2078222d35', 'EL001005', 'images/players/crystal palace/Bolsie.jpg', 'Yala Bolasie', 'MID'),
(90, '4871d72ace18481aa2ae9f2811e98117', 'EL001004', 'images/players/Chelsea/Costa.jpg', 'Diego Costa', 'MID'),
(270, '49369688035f42ff94e89bcd43e4e5fb', 'EL001014', 'images/players/Southampton/Pelle.jpg', 'Graziano Pelle', 'CF'),
(202, '4c0d2e8684b74955b019642799b8e4e1', 'EL001005', 'images/players/crystal palace/Gabbidon.jpg', 'Daniel Gabbidon', 'DF'),
(262, '4c92e95e19f44832a01584856d6cdf59', 'EL001013', 'images/players/QPR/Ferdinand.jpg', 'Rio Ferdinand', 'DF'),
(259, '4d73712604824d70afe9f30defca3789', 'EL001012', 'images/players/Newcastle/Riviere.jpg', 'Emmanuel Riviere', 'CF'),
(58, '4e4586ccc68246fb81ee9eec6c500885', 'EL001002', 'images/players/Astonvilla/richardson.jpg', 'Kieran Richardson', 'MID'),
(253, '50132d4b504e4e7486cd29bcb6b3155f', 'EL001011', 'images/players/Manutd/Carrick.jpg', 'Michael Carrick', 'MID'),
(243, '5252464af27346089a3bb4196064e969', 'EL001009', 'images/players/Liverpool/Gerrard.jpg', 'Steven Gerrard', 'MID'),
(287, '54bdc619b68e49edbe91500fc03f6f5e', 'EL001018', 'images/players/Tottenham/Vertonghen.jpg', 'Jan Vertonghen', 'DF'),
(69, '579f2dd9c4054acf9e0be7ff0f47f4c9', 'EL001004', 'images/players/Chelsea/Courtois.jpg', 'Thibaut Courtois', 'GK'),
(229, '59451d41e08e41ca8355801d552b744c', 'EL001006', 'images/players/Everton/lukaku.jpg', 'Romelu Lukaku', 'CF'),
(64, '5a53c68e53b5446fb808bf8eb817b4a7', 'EL001002', 'images/players/Astonvilla/bent.jpg', 'Darren Bent', 'ST'),
(37, '5dffcf0e3532400895c2533c224da63d', 'EL001001', 'images/players/Arsenal/sanchez.jpg', 'Alexis Sanchez', 'FW'),
(228, '612cbf16b88a4c1180de633ea01d785a', 'EL001006', 'images/players/Everton/Etoo.jpg', 'Samuel Etoo', 'CF'),
(260, '63ceadc55ef24c7a9a8a55cba60648f9', 'EL001012', 'images/players/Newcastle/Ayoze.jpg', 'Ayoze Perez', 'CF'),
(296, '6651208060484b2091d06f4075b5d6f8', 'EL001020', 'images/players/WestHam/Jaaskelainen.jpg', 'Jussi Jaaskelainen', 'GK'),
(89, '670af16b00f54572b70b2de747116904', 'EL001004', 'images/players/Chelsea/Drogba.jpg', 'Didier Drogba', 'MID'),
(82, '67346067be9946589c73210b089cc513', 'EL001004', 'images/players/Chelsea/Hazard.jpg', 'Eden Hazard', 'DF'),
(257, '6773243f4a6f4072892f79ed00afb673', 'EL001012', 'images/players/Newcastle/Coloccini.jpg', 'Fabricio Coloccini', 'DF'),
(47, '679dedabd8c7466f99127cb9d70abaa4', 'EL001002', 'images/players/Astonvilla/clark.jpg', 'Ciaran Clark', 'DF'),
(201, '69de1f6fce394a6d9ee7dfa857f5585b', 'EL001005', 'images/players/crystal palace/Delaney.jpg', 'Damien Delaney', 'DF'),
(288, '69ed6389366c4a1f957e71eed9b2fcbb', 'EL001018', 'images/players/Tottenham/Christian.jpg', 'Christian Eriksen', 'MID'),
(225, '6a5811c8d39d419fa5d24fbe1bc45107', 'EL001003', 'images/players/Burnley/Tom.jpg', 'Tom Heaton', 'GK'),
(203, '6aeab20ec8e44be1950d97ae17d8c68f', 'EL001005', 'images/players/crystal palace/Mariappa.jpg', 'Adrian Mariappa', 'DF'),
(79, '6bd07f3aeb2e47fbb322a6e2611c8cbb', 'EL001004', 'images/players/Chelsea/Fabregas.jpg', 'Francesc Fabregas', 'MID'),
(55, '6c6450f287f54ee5b27d09752b13207a', 'EL001002', 'images/players/Astonvilla/westwood.jpg', 'Ashley Westwood', 'MID'),
(224, '6cb88531991c4536b3acd5e3b1c9b367', 'EL001003', 'images/players/Burnley/Taylor.jpg', 'Matthew Taylor', 'MID'),
(35, '6cf9fe65e26041ca9e9c6cfdcf88ab02', 'EL001001', 'images/players/Arsenal/walcott.jpg', 'Theo Walcott', 'FW'),
(284, '6e46ceb5d79a42e7b8bb12e7d8d56617', 'EL001017', 'images/players/Swansea/Bony.jpg', 'Wilfried Bony', 'CF'),
(71, '6fdc9cfbd1e5467bb09c808d29a0b46f', 'EL001004', 'images/players/Chelsea/Ivanovic.jpg', 'Branislav Ivanovic', 'DF'),
(254, '715969a72ad24a55bd1836bfa9e7023a', 'EL001011', 'images/players/Manutd/Young.jpg', 'Ashley Young', 'CF'),
(200, '742b57d87f6f402ca29984079d2f40dc', 'EL001005', 'images/players/crystal palace/DAnn.jpg', 'Scott Dann', 'DF'),
(42, '75529fc5a5ec4201b3878f70ffe1f96c', 'EL001002', 'images/players/Astonvilla/guza.jpg', 'Bradley Guzan', 'GK'),
(268, '7c602dc36e0e4662baf7a2bd7d3cb4c9', 'EL001014', 'images/players/Southampton/Wanyama.jpg', 'Victor Wanyama', 'MID'),
(44, '7f08029cad8b4d3387d0799ba052718f', 'EL001002', 'images/players/Astonvilla/baker.jpg', 'Nathan Baker', 'DF'),
(277, '80c0800fadbf47eb9b7a3a630ca26084', 'EL001016', 'images/players/Sunderland/Rodwell.jpg', 'Jack Rodwell', 'DF'),
(244, '815d4a8b431d492aaf4308d2db1dd04f', 'EL001009', 'images/players/Liverpool/Balotelli.jpg', 'Mario Balotelli', 'CF'),
(196, '823536824e494fadb06e70c9e9a8401a', 'EL001005', 'images/players/crystal palace/Alexander.jpg', 'Neil Alexander', 'GK'),
(28, '834f598de88f49efb7650b2d4caeb995', 'EL001001', 'images/players/Arsenal/cazorla.jpg', 'Santi Cazorla', 'MID'),
(246, '834fe708aa9b4ba0854c8d5ad7ff955d', 'EL001010', 'images/players/ManCity/Hart.jpg', 'Joe Hart', 'GK'),
(249, '85f9205d738b4e769db7de411ea42a48', 'EL001010', 'images/players/ManCity/Dzeko.jpg', 'Edin Dzeko', 'CF'),
(43, '895d687b2ad5413bb6a8a0831a18a044', 'EL001002', 'images/players/Astonvilla/given.jpg', 'Shay Given', 'GK'),
(230, '8af5792922324866a0d020fc1555d07c', 'EL001006', 'images/players/Everton/barry.jpg', 'Gareth Barry', 'MID'),
(222, '8e5107a2ba8c4e5e9f39d17dbb4e536d', 'EL001003', 'images/players/Burnley/Lukas.jpg', 'Lukas Jutkiewicz', 'CF'),
(40, '8e863335fbd245beae47cca430d9505b', 'EL001001', 'images/players/Arsenal/gnabry.jpg', 'Serge Gnabry', 'FW'),
(206, '8f339c386bc3488a9e04f7d1ee4a9b0b', 'EL001005', 'images/players/crystal palace/Willams.jpg', 'Jerome Williams', 'MID'),
(197, '9008dd04b420439bb318740efb97785f', 'EL001005', 'images/players/crystal palace/Hennessey.jpg', 'Wayne Hennessey', 'GK'),
(235, '9088986d7fe54e51b76c2a225e00efcc', 'EL001007', 'images/players/HullCity/Jelavic.jpg', 'Nikica Jelavic', 'CF'),
(36, '912817a280d9445e9d2e684c700e34be', 'EL001001', 'images/players/Arsenal/chamberlain.jpg', 'Alex OxladeChamberlain', 'FW'),
(298, '915ccb8fa8ef4dda85f96b447e32ddde', 'EL001020', 'images/players/WestHam/Nolan.jpg', 'Kevin Nolan', 'MID'),
(87, '9232a72c241a4986a6b3797b1c345cca', 'EL001004', 'images/players/Chelsea/Willian.jpg', 'Willian', 'DF'),
(265, '93fc6e2bc8dd47b8af4301c43b3f17aa', 'EL001013', 'images/players/QPR/Vargas.jpg', 'Eduardo Vargas', 'CF'),
(45, '95db8486f0a34a928a79d17c802d2f85', 'EL001002', 'images/players/Astonvilla/vlaar.gif', 'Ron Vlaar', 'DF'),
(285, '974bae6b6ca84f6892b8070d0bbc2e15', 'EL001017', 'images/players/Swansea/Gomis.jpg', 'Bafetimbi Gomis', 'CF'),
(50, '97771eb3bdf040888f3517e8f0483925', 'EL001002', 'images/players/Astonvilla/lowton.jpg', 'Matthew Lowton', 'DF'),
(81, '98386d7c49024ac5ae3471c0a8775ba9', 'EL001004', 'images/players/Chelsea/Oscar.jpg', 'Oscar', 'DF'),
(31, '98d88206956a45bc869fb655919231eb', 'EL001001', 'images/players/Arsenal/coquelin.jpg', 'Francis Coquelin', 'MID'),
(88, '99ac88f128ef409683838a6459a36c63', 'EL001004', 'images/players/Chelsea/Baker.jpg', 'Lewis Baker', 'DF'),
(294, '99aed728df3544f6859f634ec0df5b0e', 'EL001019', 'images/players/WestBrom/Sinclair.jpg', 'Scott Sinclair', 'CF'),
(216, '99d539910f3548af8a4be3bf3eff3b7b', 'EL001005', 'images/players/crystal palace/zaha.jpg', 'Wilfried Zaha', 'MID'),
(39, '99f0595502ba4ae78f3290d97b589254', 'EL001001', 'images/players/Arsenal/welbeck.jpg', 'Danny Welbeck', 'FW'),
(62, '9c9c719058ab4695a54861fb1580b8dd', 'EL001002', 'images/players/Astonvilla/weimann.jpg', 'Andreas Weimann', 'ST'),
(273, '9cc87c6e0bec491cb6dff4e36d02e78e', 'EL001015', 'images/players/Stoke/Moses.jpg', 'Victor Moses', 'MID'),
(60, '9cfda30037a148348d078c25c1f36c2e', 'EL001002', 'images/players/Astonvilla/charles.jpg', 'Charles NZogbia', 'MID'),
(74, '9ff4d0a8551c4a56a73e1009498f8447', 'EL001004', 'images/players/Chelsea/Ake.jpg', 'Nathan Ake', 'DF'),
(226, 'a2409287a8d6401e9e6b69fa95fb5f46', 'EL001006', 'images/players/Everton/howard.jpg', 'Tim Howard', 'GK'),
(86, 'a28648cbeb7f4ea9aeed17c46fd13fab', 'EL001004', 'images/players/Chelsea/Matic.jpg', 'Nemanja Matic', 'DF'),
(84, 'a3355c48c78e41d7b3853d6dd447c45e', 'EL001004', 'images/players/Chelsea/Schurrle.jpg', 'Andre Schurrle', 'DF'),
(283, 'ab1510a82e2d442db1b52dcd271f62f4', 'EL001017', 'images/players/Swansea/Shelvey.jpg', 'Jonjo Shelvey', 'MID'),
(267, 'abc51bf92ded49dc8771b9143146d937', 'EL001014', 'images/players/Southampton/Schneiderlin.jpg', 'Morgan Schneiderlin', 'DF'),
(80, 'b062822f85fb46c5a3d17d82e7bf8d8f', 'EL001004', 'images/players/Chelsea/Ramires.jpg', 'Ramires', 'MID'),
(85, 'b1678305919d41f89fb7c5e5fee4a4c7', 'EL001004', 'images/players/Chelsea/Salah.jpg', 'Mohamed Salah', 'DF'),
(49, 'b3681e58f5414d548d0d20447cf8870e', 'EL001002', 'images/players/Astonvilla/cissokho.png', 'Aly Cissokho', 'DF'),
(255, 'b3cc8f70be364ac88d5d442efd818038', 'EL001011', 'images/players/Manutd/Persie.jpg', 'Robin van Persie', 'CF'),
(291, 'b3fa9c59d401484eab32d709fb9bb4f7', 'EL001019', 'images/players/WestBrom/Foster.jpg', 'Ben Foster', 'GK'),
(59, 'b506fbf8ce654ca89d654b82b2a07f45', 'EL001002', 'images/players/Astonvilla/sanchez.jpg', 'Carlos Sanchez', 'MID'),
(234, 'b590a4da190e46218bdf7afb18cc6955', 'EL001007', 'images/players/HullCity/Livermore.jpg', 'Jake Livermore', 'MID'),
(53, 'b67d058eab3340a4b1f2b9a78edc3495', 'EL001002', 'images/players/Astonvilla/cleverley.jpg', 'Tom Cleverley', 'MID'),
(282, 'b7889d7002be4c3db54cc02354358aa3', 'EL001017', 'images/players/Swansea/Williams.jpg', 'Ashley Williams', 'DF'),
(29, 'b8a8f4031f434d38b8e84406d4b527af', 'EL001001', 'images/players/Arsenal/flamini.jpg', 'Mathieu Flamini', 'MID'),
(231, 'b9bfed3a036d4f4096b7e6861f3cbe6b', 'EL001007', 'images/players/HullCity/Harper.jpg', 'Steve Harper', 'GK'),
(241, 'bafe9c8bcc8a46269ab671fe198855d8', 'EL001009', 'images/players/Liverpool/Mignolet.jpg', 'Simon Mignolet', 'GK'),
(237, 'bb826c768d3f423ba6fc36fddc7fdc25', 'EL001008', 'images/players/Leicester/Paul.jpg', 'Paul Konchesky', 'DF'),
(205, 'bc0c85a6b33c46b7a9c7aad2eb054eb7', 'EL001005', 'images/players/crystal palace/Ward.jpg', 'Joel Ward', 'DF'),
(213, 'bc6b426bfad243dca30bc945c8a32e71', 'EL001005', 'images/players/crystal palace/keefe.jpg', 'Stuart OKeefe', 'MID'),
(214, 'bcc47359654544519db99ffb6c4b9558', 'EL001005', 'images/players/crystal palace/Puncheon.jpg', 'Jason Puncheon', 'MID'),
(252, 'bd5325b02cad4564b6b9e5fb4603d2ae', 'EL001011', 'images/players/Manutd/Evans.jpg', 'Jonny Evans', 'DF'),
(73, 'bfed7cf7a6f543eab3fdf8d2114af4be', 'EL001004', 'images/players/Chelsea/Zouma.jpg', 'Kurt Zouma', 'DF'),
(8, 'c0e83c4f27a6478e8c498498d4291cf7', 'EL001001', 'images/players/Arsenal/monreal.jpg', 'Nacho Monreal', 'DF'),
(72, 'c119c327c12f4f0884ec56953e0207f8', 'EL001004', 'images/players/Chelsea/Luis.jpg', 'Filipe Luis', 'DF'),
(220, 'c166572a1bec4dbeab66774830b8df0e', 'EL001005', 'images/players/crystal palace/Campbell.jpg', 'Fraizer Campbell', 'ST'),
(292, 'c2ab269cf37f48bea7780315830bef68', 'EL001019', 'images/players/WestBrom/Olsson.jpg', 'Jonas Olsson', 'DF'),
(227, 'c2e75641dd054dbb87d3f183add1ced5', 'EL001006', 'images/players/Everton/baines.jpg', 'Leighton Baines', 'DF'),
(56, 'c392c3f282ad46af8475403060cfb89f', 'EL001002', 'images/players/Astonvilla/delph.jpg', 'Fabian Delph', 'MID'),
(264, 'c72b6a86614741e795a4587b419d6009', 'EL001013', 'images/players/QPR/Zamora.jpg', 'Bobby Zamora', 'CF'),
(27, 'c731286a843d4719ad07e4afb14d7fbc', 'EL001001', 'images/players/Arsenal/ramsey.jpg', 'Aaron Ramsey', 'MID'),
(242, 'c90d5c82dac44f8699d9b6c52ea081d4', 'EL001009', 'images/players/Liverpool/Skrtel.jpg', 'Martin Skrtel', 'DF'),
(2, 'ca6e0d4273d34de88763968b42ccaa4c', 'EL001001', 'images/players/Arsenal/ospina.jpg', 'David Ospina', 'GK'),
(68, 'cc41c78841a24c2bab27cb06428a5eb8', 'EL001004', 'images/players/Chelsea/PeterCech.jpg', 'Petr cech', 'GK'),
(76, 'cc6d0c2a88ca49e1a02eca90068824f4', 'EL001004', 'images/players/Chelsea/Terry.jpg', 'John Terry', 'DF'),
(217, 'cf71227c460c46eabb14cbbe4fa6ba37', 'EL001005', 'images/players/crystal palace/Chamakh.jpg', 'Marouane Chamakh', 'ST'),
(299, 'cffbd72d850c4a9cad6d1b72105896bd', 'EL001020', 'images/players/WestHam/Song.jpg', 'Alex Song', 'CF'),
(34, 'd05d39e509be4d9ea0cf44ff601f4aec', 'EL001001', 'images/players/Arsenal/giroud.jpg', 'Olivier Giroud', 'FW'),
(26, 'd16544252e0841f88750c3934aa864a4', 'EL001001', 'images/players/Arsenal/mesut.jpg', 'Mesut Ozil', 'MID'),
(52, 'd47206260cde46108084c52c66a73137', 'EL001002', 'images/players/Astonvilla/bacuna.jpg', 'Leandro Bacuna', 'MID'),
(210, 'd64d0457b29049bf96a19992c05fde3e', 'EL001005', 'images/players/crystal palace/Guedioura.jpg', 'Adlene Guedioura', 'MID'),
(1, 'd8686c83ed414e798fbca06dc03cdb19', 'EL001001', 'images/players/Arsenal/szczesny.jpg', 'Wojciech Szczesny', 'GK'),
(32, 'd99f8cc6059e43c88e2899552a1d756c', 'EL001001', 'images/players/Arsenal/zelalem.jpg', 'Gedion Zelalem', 'MID'),
(209, 'de85adbadb534203a54ad6a1e078e663', 'EL001005', 'images/players/crystal palace/Dikgacoi.jpg', 'Kagisho Dikgacoi', 'MID'),
(256, 'e14b22774e9845609e93dad628297c73', 'EL001012', 'images/players/Newcastle/Krul.jpg', 'Tim Krul', 'GK'),
(212, 'e1fdf31619f84fd48c297ecf7d9ce34d', 'EL001005', 'images/players/crystal palace/Ledley.jpg', 'Joe Ledley', 'MID'),
(4, 'e2872850e91c45aa9e99b4b6ae1338f5', 'EL001001', 'images/players/Arsenal/debuchy.jpg', 'Mathieu Debuchy', 'DF'),
(38, 'e2970402d8594e4785eac9a2e43d4083', 'EL001001', 'images/players/Arsenal/sanogo.jpg', 'Yaya Sanogo', 'FW'),
(289, 'e2dc7856c47949e6a5271d320e45eedd', 'EL001018', 'images/players/Tottenham/Soldado.jpg', 'Roberto Soldado', 'CF'),
(46, 'e35e0e1d60614289a76a17a11823d279', 'EL001002', 'images/players/Astonvilla/okore.jpg', 'Jores Okore', 'DF'),
(223, 'e4680effa8ce4a039422fa51dcbe8b05', 'EL001003', 'images/players/Burnley/Reid.jpg', 'Steven Reid', 'DF'),
(295, 'e49f2dd6db364622b8269711d6869e03', 'EL001019', 'images/players/WestBrom/Anichebe.jpg', 'Victor Anichebe', 'CF'),
(7, 'e4c1ab8259ff4ee19411288952f39cc0', 'EL001001', 'images/players/Arsenal/kosicenly.jpg', 'Laurent Koscielny', 'DF'),
(65, 'e554e97bda9c451ca3d4d17404112443', 'EL001002', 'images/players/Astonvilla/benteke.jpg', 'Christian Benteke', 'ST'),
(204, 'e55cf29064024bb795f1d08b5d676c4b', 'EL001005', 'images/players/crystal palace/Macarthy.jpg', 'Paddy McCarthy', 'DF'),
(239, 'e6f5ba70e29b4d9e9ffb39258771f4ad', 'EL001008', 'images/players/Leicester/Wood.jpg', 'Chris Wood', 'CF'),
(211, 'e77690aad59f421f98a2bd9d4063b59e', 'EL001005', 'images/players/crystal palace/jedinak.jpg', 'Mile Jedinak', 'MID'),
(77, 'ecf1d883cce24f1cb515219605f7af65', 'EL001004', 'images/players/Chelsea/Azpilicueta.jpg', 'Cesar Azpilicueta', 'DF'),
(232, 'ed19b4c45e1c40a08766b154595af15e', 'EL001007', 'images/players/HullCity/Chester.jpg', 'Chester', 'DF'),
(247, 'ee962e828b79408b9c24f219e165765f', 'EL001010', 'images/players/ManCity/Kompany.jpg', 'Vincent Kompany', 'DF'),
(5, 'f242cd3966b94e2d9fb459767abfc09f', 'EL001001', 'images/players/Arsenal/gibbs.jpg', 'Kieran Gibbs', 'DF'),
(66, 'f4268b2841704b588ef8f390ae891096', 'EL001002', 'images/players/Astonvilla/kozak.jpg', 'Libor Kozak', 'ST'),
(51, 'f655f30bab6d493692d1b2805880c307', 'EL001002', 'images/players/Astonvilla/stevens.jpg', 'Enda Stevens', 'DF'),
(61, 'f6c7764ae74e4cacb47647a19dc7bf66', 'EL001002', 'images/players/Astonvilla/grealish.jpg', 'Jack Grealish', 'MID'),
(290, 'f7be874d8b254dbeb185600f43c3074b', 'EL001018', 'images/players/Tottenham/Adebayor.jpg', 'Emmanuel Adebayor', 'CF'),
(30, 'f95bf21f50584053a1ccbc7228274970', 'EL001001', 'images/players/Arsenal/diaby.jpg', 'Abou Diaby', 'MID'),
(6, 'fa1e667ba182479fac7825dd95cc2cbe', 'EL001001', 'images/players/Arsenal/per.jpg', 'Per Mertesacker', 'DF'),
(300, 'fa794881a40d4914aa7df5d2369f8bc5', 'EL001020', 'images/players/WestHam/Valencia.jpg', 'Enner Valencia', 'CF'),
(275, 'fab79a14930b40bca589ba832d913b5a', 'EL001015', 'images/players/Stoke/Krkic.jpg', 'Bojan Krkic', 'CF'),
(293, 'ff8e2f07d85748a9b40972a0b1042188', 'EL001019', 'images/players/WestBrom/Yacob.jpg', 'Claudio Yacob', 'MID'),
(83, 'ffb644b73ade4d4caf10455e476b60bd', 'EL001004', 'images/players/Chelsea/Mikel.jpg', 'John Obi Mikel', 'DF'),
(258, 'ffde511e5a7c4b9f90c1ec7d472ccb09', 'EL001012', 'images/players/Newcastle/Sissoko.jpg', 'Moussa Sissoko', 'MID');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE IF NOT EXISTS `role` (
  `roleId` int(11) NOT NULL AUTO_INCREMENT,
  `roleCode` char(2) NOT NULL,
  `roleDescription` varchar(40) NOT NULL,
  PRIMARY KEY (`roleCode`),
  UNIQUE KEY `roleId` (`roleId`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`roleId`, `roleCode`, `roleDescription`) VALUES
(1, 'AD', 'Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `team`
--

CREATE TABLE IF NOT EXISTS `team` (
  `teamId` int(11) NOT NULL AUTO_INCREMENT,
  `divisionCode` varchar(10) NOT NULL,
  `teamCode` varchar(30) NOT NULL,
  `teamName` varchar(50) NOT NULL,
  `managerCode` varchar(10) NOT NULL,
  `teamLogo` varchar(50) NOT NULL,
  `AchievementCode` varchar(50) DEFAULT NULL,
  `teamAlias` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`teamCode`),
  UNIQUE KEY `teamId` (`teamId`,`divisionCode`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `team`
--

INSERT INTO `team` (`teamId`, `divisionCode`, `teamCode`, `teamName`, `managerCode`, `teamLogo`, `AchievementCode`, `teamAlias`) VALUES
(1, 'EL001', 'EL001001', 'Arsenal', 'MG001', 'images/teams/Arsenal.png', NULL, ''),
(10, 'EL001', 'EL0010010', 'Manchester City', 'MG010', 'images/teams/mancity.jpg', NULL, ''),
(17, 'EL001', 'EL0010017', 'Swansea City', 'MG017', 'images/teams/SwanseaCity.jpg', NULL, ''),
(2, 'EL001', 'EL001002', 'AstonVilla', 'MG002', 'images/teams/Astonvilla.png', NULL, ''),
(3, 'EL001', 'EL001003', 'Burnley', 'MG003', 'images/teams/burnley.jpg', NULL, ''),
(4, 'EL001', 'EL001004', 'Chelsea', 'MG004', 'images/teams/chelsea.jpg', NULL, ''),
(5, 'EL001', 'EL001005', 'Crystal Palace', 'MG005', 'images/teams/Crystal.png', NULL, ''),
(6, 'EL001', 'EL001006', 'Everton', 'MG006', 'images/teams/everton.jpg', NULL, ''),
(7, 'EL001', 'EL001007', 'Hull City', 'MG007', 'images/teams/Hull.jpg', NULL, ''),
(8, 'EL001', 'EL001008', 'Leicester City', 'MG008', 'images/teams/Leicester.jpg', NULL, ''),
(9, 'EL001', 'EL001009', 'Liverpool', 'MG009', 'images/teams/liverpool.jpg', NULL, ''),
(11, 'EL001', 'EL001011', 'Manchester United', 'MG011', 'images/teams/manutd.jpg', NULL, ''),
(12, 'EL001', 'EL001012', 'Newcastle United', 'MG012', 'images/teams/Newcastle.jpg', NULL, ''),
(13, 'EL001', 'EL001013', 'Queens Park Rangers', 'MG013', 'images/teams/QueensPark.jpg', NULL, ''),
(14, 'EL001', 'EL001014', 'Southampton', 'MG014', 'images/teams/Southampton.png', NULL, ''),
(15, 'EL001', 'EL001015', 'Stoke City', 'MG015', 'images/teams/stokecity.png', NULL, ''),
(16, 'EL001', 'EL001016', 'Sunderland', 'MG016', 'images/teams/Sunderland.jpg', NULL, ''),
(18, 'EL001', 'EL001018', 'Tottenham Hotspur', 'MG018', 'images/teams/Tottenham.png', NULL, ''),
(19, 'EL001', 'EL001019', 'West Bromwich Albion', 'MG019', 'images/teams/WestBromwichAlbion.png', NULL, ''),
(20, 'EL001', 'EL001020', 'West Ham United', 'MG020', 'images/teams/WestHam.png', NULL, '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
